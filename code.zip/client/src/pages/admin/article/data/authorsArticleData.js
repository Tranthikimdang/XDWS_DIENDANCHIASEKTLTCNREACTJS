
// eslint-disable-next-line import/no-anonymous-default-export
export default {
  columns: [
    { name: "no", align: "left" },
    { name: "fuction", align: "left" },
    { name: "author", align: "left" },
    { name: "content", align: "left" },
    { name: "date", align: "left" },
    { name: "action", align: "left" },
  ],
};
