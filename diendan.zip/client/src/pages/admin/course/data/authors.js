
export default {
  columns: [
    { name: "no", align: "left", label: "Số thứ tự" }, 
    { name: "image", align: "left", label: "Hình ảnh" }, 
    { name: "name", align: "left", label: "Tên sản phẩm" }, 
    { name: "price", align: "left", label: "Giá" }, 
    { name: "discount", align: "left", label: "Giảm giá" }, 
    { name: "quality", align: "left", label: "Chất lượng" }, 
    { name: "updated_at", align: "left", label: "Ngày cập nhật" }, 
    { name: "action", align: "left", label: "Thao tác" }, 
  ],
};
