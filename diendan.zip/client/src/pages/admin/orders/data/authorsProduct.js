export default {
  columns: [
    { name: "no", align: "left"}, 
    { name: "Note", align: "left" }, 
    { name: "ProductName", align: "left" }, 
    { name: "OrderDay", align: "left" }, 
    { name: "UserName", align: "left" }, 
    { name: "actions", align: "left"}, 
  ],
};

