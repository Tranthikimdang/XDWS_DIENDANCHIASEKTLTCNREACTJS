/* eslint-disable import/no-anonymous-default-export */
  export default {
    columns: [
      { name: "no", align: "left" },
      { name: "items", align: "left" },
      { name: "user_name", align: "left" },
      { name: "order_day", align: "left" },
      { name: "paymentMethod", align: "left" },
      { name: "totalAmount", align: "left" },
      { name: "status", align: "left" },
      { name: "actions", align: "left" },
    ],
  };
  