import { SET_USER } from "./constants";

export const setAccount = payload => ({
    type: SET_USER,
    payload
})