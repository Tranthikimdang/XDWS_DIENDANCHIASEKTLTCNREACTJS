/* eslint-disable import/no-anonymous-default-export */
export default {
  columns: [
    { name: "no", align: "left" },
    { name: "name", align: "left" },
    { name: "avatar", align: "center" }, // Thay đổi tên cột "ảnh đại diện" thành "avatar" cho dễ quản lý
    { name: "email", align: "left" },
    { name: "location", align: "left" },
    { name: "phone", align: "left" },
    { name: "role", align: "left" },
    { name: "action", align: "left" },
  ],
};
