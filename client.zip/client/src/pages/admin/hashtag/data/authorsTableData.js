export default {
  columns: [
    { name: "no", align: "left" },
    { name: "name", align: "left" },
    { name: "updated_at", align: "left" },
    { name: "action", align: "left" },
  ],
};
