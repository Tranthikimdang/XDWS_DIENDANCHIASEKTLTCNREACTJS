/* eslint-disable import/no-anonymous-default-export */

export default {
  columns: [
    { name: "no", align: "left", label: "Số thứ tự" }, 
    { name: "name", align: "left", label: "Tên sản phẩm" }, 
    { name: "video", align: "left", label: "Video" }, 
    { name: "updated_at", align: "left", label: "Ngày cập nhật" }, 
    { name: "action", align: "left", label: "Thao tác" }, 
  ],
};
